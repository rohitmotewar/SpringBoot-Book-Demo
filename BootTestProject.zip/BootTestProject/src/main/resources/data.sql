Insert into book (isbn,title,author,price,stock,genre) values('1254531','Networking','RK',120.12,65,'TECH');
Insert into book (isbn,title,author,price,stock,genre) values('121dfsvdfs','Let us C','YK',180.12,65,'TECH');
Insert into book (isbn,title,author,price,stock,genre) values('124sfv','Let us C++','YK',190.12,65,'TECH');