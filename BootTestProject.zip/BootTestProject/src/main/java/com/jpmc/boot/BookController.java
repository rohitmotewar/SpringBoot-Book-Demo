package com.jpmc.boot;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.jpmc.boot.bean.Book;
import com.jpmc.boot.bean.LimitConfg;
import com.jpmc.boot.service.intefaces.BookServiceI;

@RestController
@CrossOrigin(origins = "*", maxAge=3600)
public class BookController 
{
	@Autowired
	//private BookRepo bookRepo;
	
	private BookServiceI bookservice;
	
	@Autowired
	private LimitConfg limitConfig;
	
	@GetMapping("/hello")
	public String sayHello()
	{
		return "Hi, you are in Spring Boot App";
		
	}
	
	
/*	//@GetMapping("/getbook") // OR
	@RequestMapping(method=RequestMethod.GET, value="/getbook")
	public Book getBook()
	{
		 Book book =new Book("45787","JS HF","MMM",1224.2,45,"TECH");
		 return book;
		 
	}*/
		
	
	@RequestMapping(method=RequestMethod.GET, value="/getbooklist")
	public List<Book> getBooks()
	{
		//		return bookRepo.findAll();
		return bookservice.getAllBooks();
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/addbook")
	public Book addBook(@RequestBody Book book)
	{
		/*bookRepo.save(book);
		return book;
		//return "Book Added";*/	
		
		bookservice.addBook(book);
		return book;
		
	}
	
	
	@Transactional
	@RequestMapping(method=RequestMethod.POST, value="/deletebook/isbn/{isbn}")
	public String deleteBook(@PathVariable("isbn") String isbn)
	{
		/*bookRepo.deleteById(isbn);
		return "Book Deleted";*/
		
		bookservice.deleteBook(isbn);
		return "Book Deleted";
		
	}
	
	//You use HTTP delete method to delete the obj as ;
	
	/*@Transactional
	@DeleteMapping("/deletebook/isbn/{isbn}")
	public String deleteBook(@PathVariable("isbn") String isbn)
	{
		bookRepo.deleteById(isbn);
		return "Book Deleted";
		bookservice.deleteBook(isbn);
		return "Book Deleted";
		
	}*/
	
	
	@Transactional
	@RequestMapping(method=RequestMethod.POST,value="/updatebook/isbn/{isbn}/stock/{stock}/price/{price}")
	public String updateBook(@PathVariable("isbn") String isbn,@PathVariable("stock") long stock,@PathVariable("price") double price)
	{
		/*System.out.println("vals are"+isbn+":"+stock);
		bookRepo.findById(isbn).get().setStock(stock);
		return "book updated";*/
		
		bookservice.updateBook(isbn, price, stock);
		return "Book Updated";
		
	}
	
	@Transactional
	@RequestMapping(method=RequestMethod.POST, value="/getbook/isbn/{isbn}")
	public Book getBook(@PathVariable("isbn") String isbn)
	{
		Book book=bookservice.getBook(isbn);
		return book;
	}
	
	@Transactional
	@RequestMapping(method=RequestMethod.POST, value="/getbytitle&author/title/{title}/author/{author}")
	public List<Book> findByTitleAndAuthor(@PathVariable("title")String title,@PathVariable("author")String author)
	{
		List<Book> booklist= bookservice.findByTitleAndAuthor(title, author);
		return booklist;
		
	}
	
	@Transactional
	@RequestMapping(method=RequestMethod.POST, value="/bookBygenre/genre/{genre}")
	public List<Book> findByGenre(@PathVariable("genre")String genre)
	{
		List<Book> genreList=bookservice.findByGenre(genre);
		return genreList;
	}
	
	
	@GetMapping("/getByPrice")
	public List<Book> findByMinAndMaxRange(Double max, Double min) {
		min = limitConfig.getMin();
		max = limitConfig.getMax();
		return bookservice.findByMinAndMaxRange(max, min);
	}
	

	
	
}
