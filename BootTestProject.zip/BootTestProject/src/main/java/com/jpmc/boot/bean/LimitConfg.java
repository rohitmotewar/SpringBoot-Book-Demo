package com.jpmc.boot.bean;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("limits-service")
public class LimitConfg 
{

	private double min;
	private double max;
	public double getMin() {
		return min;
	}
	public void setMin(double min) {
		this.min = min;
	}
	public double getMax() {
		return max;
	}
	public void setMax(double max) {
		this.max = max;
	}
	public LimitConfg(double min, double max) {
		super();
		this.min = min;
		this.max = max;
	}
	public LimitConfg() {
		super();
	}
	@Override
	public String toString() {
		return "LimitConfg [min=" + min + ", max=" + max + "]";
	}
	
	
}
