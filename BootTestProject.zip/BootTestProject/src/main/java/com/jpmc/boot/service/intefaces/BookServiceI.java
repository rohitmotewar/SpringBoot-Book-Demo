package com.jpmc.boot.service.intefaces;

import java.util.List;

import com.jpmc.boot.bean.Book;

public interface BookServiceI 
{
	public List<Book> getAllBooks();
	public  boolean deleteBook(String isbn);
	public Book addBook(Book book);
	public boolean updateBook(String isbn,double price,long stock);
	
	//public List<Book> getAllBooks(String genre);
	public Book getBook(String isbn);
	
	public List<Book> findByTitleAndAuthor(String title,String author);
	
	public List<Book> findByGenre(String Genre);
	
	public int updateStockToNewStock(long oldStock,long newStock);
	
	public List<Book> findByMinAndMaxRange(double max, double min);
	
	
	
	
	
}
