package com.jpmc.boot;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.jpmc.boot.bean.Book;
import com.jpmc.boot.bean.LimitConfg;
import com.jpmc.boot.service.intefaces.BookServiceI;

@SpringBootApplication
public class BootTestProjectApplication implements CommandLineRunner //It is notrequired to imple CommandLineRunner , if you use it wil lpruint the itself in console soyou dont need to run it on controllerpostman everytime.
{
	
	@Autowired
	private BookServiceI bookservice;
	
	@Autowired
	private LimitConfg limitsConfig;
	
	@Value(value="${server.port}")
	int serverPort;
	
	
	public static void main(String[] args) {
		SpringApplication.run(BootTestProjectApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		List<Book> bookList=bookservice.findByTitleAndAuthor("Advance JQuery", "MMM");
		System.out.println(bookList);
		
		List<Book> bookList2=bookservice.findByGenre("Science");
		
		System.out.println(bookList2);
		
		int book=bookservice.updateStockToNewStock(100,30);
		System.out.println(book);
		
		System.out.println(bookservice.getAllBooks());
		
		//Min max from Prop file
		
		System.out.println(limitsConfig.getMax()+" "+limitsConfig.getMin());
		System.out.println("PORT-"+serverPort);
		
		System.out.println(limitsConfig.getMax());
		System.out.println(limitsConfig.getMin());
		
	}

}

