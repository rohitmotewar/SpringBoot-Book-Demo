package com.jpmc.boot.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Address 
{
	@Id
	private String addressId;
	private String city;
	private String flatNo;
	private String area;
	private long pincode;
	public String getAddressId() {
		return addressId;
	}
	public void setAddressId(String addressId) {
		this.addressId = addressId;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getFlatNo() {
		return flatNo;
	}
	public void setFlatNo(String flatNo) {
		this.flatNo = flatNo;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public long getPincode() {
		return pincode;
	}
	public void setPincode(long pincode) {
		this.pincode = pincode;
	}
	public Address(String addressId, String city, String flatNo, String area, long pincode) {
		super();
		this.addressId = addressId;
		this.city = city;
		this.flatNo = flatNo;
		this.area = area;
		this.pincode = pincode;
	}
	public Address() {
		super();
	}
	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", city=" + city + ", flatNo=" + flatNo + ", area=" + area
				+ ", pincode=" + pincode + "]";
	}
	
	
	
	
}
