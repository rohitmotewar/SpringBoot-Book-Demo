package com.jpmc.boot.service.classes;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jpmc.boot.bean.Book;
import com.jpmc.boot.bean.LimitConfg;
import com.jpmc.boot.interfaces.BookRepo;
import com.jpmc.boot.service.intefaces.BookServiceI;

//@Service  // If u user @Service you dont need to use @Transactional.
@Component
public class BookService implements BookServiceI
{
	@Autowired
	private BookRepo bookrepo;
	private LimitConfg limitConfig;
	
	@Override
	public List<Book> getAllBooks() {
		
		return bookrepo.findAll();
		 
	}

	@Transactional
	@Override
	public boolean deleteBook(String isbn) {
		
		bookrepo.deleteById(isbn);
		return true;
		
	}

	@Override
	public Book addBook(Book book) {
		bookrepo.save(book);
		return book;
		
	}

	@Transactional
	@Override
	public boolean updateBook(String isbn, double price, long stock) {
		Book bookUp=bookrepo.findById(isbn).get();
		bookUp.setPrice(price);
		bookUp.setStock(stock);

		return true;
	}

	@Override
	public List<Book> findByGenre(String genre) {
		
		return bookrepo.findByGenre(genre);
		
	}

	
	@Override
	public Book getBook(String isbn) {
		
		Book book=bookrepo.findById(isbn).get();
		return book;
	//return	bookrepo.findById(isbn);
		 
	}

	@Override
	public List<Book> findByTitleAndAuthor(String title, String author) {
		
		return bookrepo.findByTitleAndAuthor(title, author);
//		return null;
	}
	
	@Transactional
	@Override
	public int updateStockToNewStock(long oldStock, long newStock) {
		
		return bookrepo.updateStockToNewStock(oldStock, newStock);
		 //true;
	}

	@Override
	public List<Book> findByMinAndMaxRange(double max,double min)
	{
		return bookrepo.findByMinAndMaxRange(max, min);
		
	}
	
}
