package com.jpmc.boot.bean;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class User 
{
	@Id
	
	private String email;
	private String name;
	private Date dob;
	
	//private Address address;
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	/*public Address getAddress() {
		return address;
	}*/
	/*public void setAddress(Address address) {
		this.address = address;
	}*/
	public User(String email, String name, Date dob, Address address) {
		super();
		this.email = email;
		this.name = name;
		this.dob = dob;
		//this.address = address;
	}
	
	@Override
	public String toString() {
		return "User [email=" + email + ", name=" + name + ", dob=" + dob + "]";
	}
	
	public User() {
		super();
	
	
	}
	
	
}
